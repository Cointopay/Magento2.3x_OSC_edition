# Cointopay Payment Gateway for Magento 2
